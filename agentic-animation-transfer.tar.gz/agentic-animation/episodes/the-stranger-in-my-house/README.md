# THE STRANGER IN MY HOUSE — pipeline-ready package

This package contains the authored source (`episode.yml`), the measured English
audio timeline (`audio/`) and the compiled performance manifest
(`performance.json`). It is **not** a rendered film: this host cannot run a
Remotion render. Render it on a normal Linux x86_64/arm64 host with a working
Chromium and the documented memory/disk budget.

## Measured state

- `check`: OK — 7 scenes, 14 statements.
- `make --synthesize-unmatched`: OK — 14 takes, 7 reused, 0 unmatched.
- Compiled duration: **45.438 s** (1080 frames at 24 fps nominal; actual
  45.437687 s). Audio: 44.1 kHz mono PCM mix.
- Caption style in the manifest: pink `#ff4fa8`, black 5 px outline, 1.45×
  length-based font size.
- Three distinct Edge voices: `en-US-GuyNeural` (+6%, +8 Hz) for Danny,
  `en-US-JennyNeural` (-2%, -4 Hz) for Mom, `en-US-AnaNeural` (+8%, +6 Hz) for
  Sister.

## Honest substitutions

The installed library has no modern family cast, no domestic bedroom/hallway/
supermarket sets, no door/bed/grocery bag/chocolate props and no knock/open/hide
procedures. The source uses the closest reusable stand-ins:

| Requirement | Stand-in used | Consequence |
| --- | --- | --- |
| Danny | `figure/athlete_a` | young male in sportswear, not a child |
| Mom | `figure/gymnast_b` | adult build in a leotard |
| Little sister | `figure/lin_b_draft` | student silhouette, not a small child |
| Bedroom | `set/qingyun_dormitory` | historical dorm with a painted bed |
| Hallway | `set/school_corridor` | institutional corridor |
| Supermarket | `set/canteen_counter_m3` | school-shop counter |
| Door | `prop/mirror` panel | no opening motion; reveal is a staging cut |
| Groceries | `prop/scroll` | wrapped parcel, not a grocery bag |
| Chocolate | `prop/roasted_sausage` | elongated food, used only as the pointing target |
| Mom's text message | voiced by Mom's voice in a cutaway | no in-engine text-over-phone overlay exists |
| Knock | two `action.pat` beats + click cue | no knock action or audio cue exists |
| BGM | ending cadence only | the YAML path has no general BGM call; `music.xuehua` is a Chinese song bed and does not fit |

Also unverified and unmet here: real lip-sync (`lipsync: none` because the
Rhubarb binary is absent; the motor's deterministic mouth flap is used),
representative visual QA stills, and final MP4 stream/loudness checks. The
engine reports teleport and sudden-move warnings at scene cuts because staging
changes actor placement between scenes; camera-overflow warnings are expected
because the 1920×1080 painted stage is framed for a 1080×1920 viewport.

## Render on a capable host

Use a normal Linux host with Node ≥ 20, Chromium, ≥ 6 GB free RAM and ≥ 20 GB
free disk. Put this in `anim.config.local.json` (gitignored):

```json
{
  "adapters": { "lipsync": "rhubarb" },
  "video": {
    "width": 1080,
    "height": 1920,
    "fps": 24,
    "crf": 30,
    "captions": {
      "color": "#ff4fa8",
      "outlineColor": "#000000",
      "outlineWidth": 5,
      "fontScale": 1.45
    }
  },
  "render": {
    "concurrency": 4,
    "encode": { "codec": "auto" }
  },
  "tts": { "speed": 1.05 }
}
```

Then:

```bash
npm run anim -- check episodes/the-stranger-in-my-house/episode.yml
npm run anim -- make episodes/the-stranger-in-my-house/episode.yml --synthesize-unmatched
npm run anim -- render-yaml episodes/the-stranger-in-my-house/episode.yml
ffprobe -v error -show_entries format=duration \
  -show_entries stream=codec_name,width,height \
  episodes/the-stranger-in-my-house/dist/the_stranger_in_my_house.mp4
```

On this host the equivalent render probe fails before frames are produced:

```text
ANIM_BROWSER=/usr/bin/chromium NODE_OPTIONS=<rspack-stub> \
npm run anim -- render-yaml episodes/the-stranger-in-my-house/episode.yml \
  --duration 2 --threads 1 --force
ERROR render-yaml failed: Unsupported OS: android, architecture: arm64
```

Chromium 156 at `/usr/bin/chromium` also exits 133 (core dump) on a plain
`--headless --dump-dom about:blank` probe. The rspack native binding is missing
for this Android/arm64 Node, so all CLI runs here need the module-load stub used
for `check`/`make`; a capable host does not.
