---
name: make-character
description: Create or approve an immutable category puppet for this engine when an episode needs a character absent from the approved library.
---

# make-character

Read [docs/6_ARCHITECTURE.md](../../../docs/6_ARCHITECTURE.md),
[docs/6_DECISIONS.md](../../../docs/6_DECISIONS.md), and [docs/7_SCHEMAS.md](../../../docs/7_SCHEMAS.md).
Read [docs/6_WORLD_PLUGIN_CONTRACT.md](../../../docs/6_WORLD_PLUGIN_CONTRACT.md) for category layout and face-rig/overlay ownership.
Episodes pin approved assets; drafts do not enter production rendering.
When producing or reworking the figure artwork itself at the accepted bar, use
[art-asset-production](../art-asset-production/SKILL.md) for the disposable
draft library, the `svg-bone-parts` generator recipe and the evidence bundle.

1. Run `npm run anim -- doctor` and confirm the image-generation environment.
   Ground the brief and record provenance.
2. Create a draft and identity anchor. Stop for human anchor approval before
   deriving parts.
3. Generate, cut, and rig complete layered parts, pivots, sockets,
   face/eye/mouth shapes, and compatible motion. Record model and license.
4. Render pose, expression, and viseme stills; apply [qa-stills](../qa-stills/SKILL.md).
5. Approve the category asset path and manifest entry; later looks are separate approved asset paths.

Use immutable [algorithmic-art](../algorithmic-art/SKILL.md),
[canvas-design](../canvas-design/SKILL.md), or [svg-creator](../svg-creator-skill/SKILL.md)
only for their native asset formats. This skill owns library integration and QA.

Completion: a pinned approved version exists, metadata is complete, and sampled
poses/visemes pass visual QA.
