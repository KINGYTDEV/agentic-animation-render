import { existsSync, writeFileSync } from "node:fs";
import { basename, dirname, join, relative, resolve } from "node:path";
import {
  compileEpisode as coreCompileEpisode,
  hashJson,
  loadAssetRegistry as coreLoadAssetRegistry,
  loadAudioCues as coreLoadAudioCues,
  loadNarrowEpisode,
  loadPlugins as coreLoadPlugins,
  readJson,
  synchronizeYamlAudioStarts,
  segmentYamlAudio,
  yamlAudioSourceFromEpisode,
  writeGenerated,
  YamlAudioPreparationSchema,
  resolvePath,
  type AssetRegistry,
  type AudioCueAsset,
  type LoadedPlugin,
  type CompiledEpisode,
  type ProcedureResolver,
  type RenderReport,
  type SpeechTimingProvider,
  type YamlAudioPreparationArtifact,
} from "@anim/core";
import type { LipsyncAdapter, RendererAdapter } from "@anim/core";
import type { StageContext } from "../runtime/context";
import { assembleYamlAudio, yamlAudioStage } from "./yamlAudio";
import { stageNow } from "./audioSupport";

import { detectCameraOverflows, describeCameraOverflows, detectPropDiscontinuities, describePropDiscontinuities, detectTeleports, describeTeleports } from "@anim/studio";

export const YAML_PERFORMANCE_MANIFEST_NAME = "performance.json";
export const YAML_AUDIO_ARTIFACT_NAME = "yaml-audio.json";

export interface YamlMakeOptions {
  provider?: string;
  synthesizeUnmatched?: boolean;
  voiceSpeed?: number;
}

export interface YamlRenderOptions {
  threads?: number;
  duration?: number;
  scale?: number;
  fps?: number;
  crf?: number;
  force?: boolean;
  voiceSpeed?: number;
}

export interface YamlRenderRequest {
  manifestPath: string;
  outPath: string;
  fps: number;
  crf: number;
  threads: number;
  duration?: number;
  scale?: number;
  force?: boolean;
  encode?: {codec?: "auto" | "av1" | "h265" | "h264"; crf?: number; preset?: number | string; audioBitrate?: string};
}

export interface YamlPipelineDependencies {
  loadAssetRegistry?: (libraryRoot: string) => Promise<AssetRegistry>;
  loadPlugins?: (libraryRoot: string) => Promise<LoadedPlugin[]>;
  loadAudioCues?: (libraryRoot: string) => Promise<Record<string, AudioCueAsset>>;
  compileEpisode?: typeof coreCompileEpisode;
  prepareAudio?: (
    ctx: StageContext,
    episodePath: string,
    provider?: string,
    _synthesizeUnmatched?: boolean,
    _voiceSpeed?: number,
  ) => Promise<YamlAudioPreparationArtifact>;
  speechTimingProvider?: SpeechTimingProvider;
  renderManifest?: (ctx: StageContext, request: YamlRenderRequest) => Promise<RenderReport>;
  /** Compiler timing seam for procedure implementations, never guessed by CLI. */
  procedureResolver?: ProcedureResolver;
  now?: () => string;
}

export interface YamlCheckResult {
  episodePath: string;
  episodeId: string;
  scenes: number;
  spokenTakes: number;
}

export interface YamlMakeResult extends YamlCheckResult {
  audioPath: string;
  manifestPath: string;
  totalDuration: number;
}

export interface YamlRenderResult extends YamlMakeResult {
  rendered: boolean;
  outPath?: string;
  report?: RenderReport;
}

interface ResolvedEpisode {
  path: string;
  dir: string;
  slug: string;
  episode: Awaited<ReturnType<typeof loadNarrowEpisode>>;
}

/** Resolve the author input without making the caller cd into the project. */
export async function resolveYamlEpisode(ctx: StageContext, input: string): Promise<ResolvedEpisode> {
  const candidates = [resolve(ctx.rootDir, input), resolve(process.cwd(), input)];
  const path = candidates.find((candidate) => existsSync(candidate));
  if (!path) throw new Error(`yaml: episode file does not exist: ${candidates[0]}`);
  if (basename(path) !== "episode.yml") {
    throw new Error(`yaml: canonical input must be named episode.yml (got ${path})`);
  }
  const episode = await loadNarrowEpisode(path);
  return { path, dir: dirname(path), slug: basename(dirname(path)), episode };
}

/** Validate YAML, immutable assets, procedure contracts, and compiler state. */
export async function checkYamlEpisode(
  ctx: StageContext,
  input: string,
  deps: YamlPipelineDependencies = {},
): Promise<YamlCheckResult> {
  const resolved = await resolveYamlEpisode(ctx, input);
  const registry = await (deps.loadAssetRegistry ?? coreLoadAssetRegistry)(libraryDir(ctx));
  const plugins = await (deps.loadPlugins ?? coreLoadPlugins)(libraryDir(ctx));
  const compiled = await (deps.compileEpisode ?? coreCompileEpisode)(resolved.path, {
    registry,
    plugins,
    speechTiming: deps.speechTimingProvider ?? dryRunSpeechTiming,
  });
  const result = resultOf(resolved, compiled, spokenTakeCount(resolved));
  process.stdout.write(
    `check: OK ${resolved.path} (${result.scenes} scene(s), ${result.spokenTakes} spoken take(s))\n`,
  );
  return result;
}

/** Prepare measured audio, then compile the one renderer-neutral manifest. */
export async function makeYamlEpisode(
  ctx: StageContext,
  input: string,
  opts: YamlMakeOptions = {},
  deps: YamlPipelineDependencies = {},
): Promise<YamlMakeResult> {
  validateVoiceSpeed(opts.voiceSpeed, "make");
  const resolved = await resolveYamlEpisode(ctx, input);
  const registry = await (deps.loadAssetRegistry ?? coreLoadAssetRegistry)(libraryDir(ctx));
  const plugins = await (deps.loadPlugins ?? coreLoadPlugins)(libraryDir(ctx));
  let preparation = await (deps.prepareAudio ?? prepareYamlAudio)(ctx, resolved.path, opts.provider, opts.synthesizeUnmatched, opts.voiceSpeed);
  if (preparation.unmatchedCount) {
    throw new Error(
      `make: ${preparation.unmatchedCount} YAML speech take(s) have no exact source audio; ` +
      "rerun with --synthesize-unmatched or provide exact legacy takes",
    );
  }
  const timing = deps.speechTimingProvider ?? speechTimingFromPreparation(preparation);
  const compiled = await (deps.compileEpisode ?? coreCompileEpisode)(resolved.path, {
    registry,
    plugins,
    speechTiming: timing,
    voiceSpeed: opts.voiceSpeed ?? ctx.config.tts.speed,
  });
  const starts = speechStarts(preparation, compiled);
  preparation = synchronizeYamlAudioStarts(preparation, starts);
  const audioPath = preparation.takes.some((take) => take.audioPath)
    ? await assembleYamlAudio(resolved.dir, preparation, compiled.totalDuration)
    : "";
  preparation = { ...preparation, ...(audioPath ? {mixPath: audioPath} : {}) };
  writeGenerated(join(resolved.dir, "audio", YAML_AUDIO_ARTIFACT_NAME), YamlAudioPreparationSchema, preparation, {
    stage: "yaml-audio",
    tool: "yaml-audio-migration",
    at: deps.now?.() ?? stageNow(),
    inputs: { episode: resolved.episode, provider: opts.provider ?? ctx.config.adapters.tts, starts, totalDuration: compiled.totalDuration },
  });
  const manifestPath = join(resolved.dir, YAML_PERFORMANCE_MANIFEST_NAME);
  await attachMouthCues(ctx, resolved, preparation);
  attachSpeechMouth(compiled, preparation);
  const manifest = performanceManifest(ctx, resolved, compiled, preparation, deps.now?.() ?? stageNow());
  // Cue audio is plugin-owned: resolve each cue's file here so the manifest is
  // self-contained and the renderer never looks up library paths itself.
  const cueAssets = await (deps.loadAudioCues ?? coreLoadAudioCues)(libraryDir(ctx));
  const embeddedCues: Record<string, {kind: string; path: string}> = {};
  for (const [cue, asset] of Object.entries(cueAssets)) {
    const abs = join(asset.dir, asset.file);
    if (!existsSync(abs)) throw new Error(`make: audio cue "${cue}" asset missing: ${abs}`);
    embeddedCues[cue] = {kind: asset.kind, path: relative(resolved.dir, abs).replaceAll("\\", "/")};
  }
  const audioRecord = (manifest as Record<string, unknown>).audio;
  const manifestWithCues = {...manifest, audio: {...(audioRecord ?? {} as Record<string, unknown>), cues: embeddedCues}};
  writeFileSync(manifestPath, JSON.stringify(manifestWithCues, null, 2) + "\n");
  const result = resultOf(resolved, compiled, preparation.takes.length, {
    audioPath,
    manifestPath,
    totalDuration: compiled.totalDuration,
  });
  process.stdout.write(`make: wrote ${manifestPath} (${compiled.totalDuration.toFixed(3)}s)\n`);
  // Shift-left defect detection: loud warnings right after compile.
  for (const line of describeTeleports(detectTeleports(manifestWithCues as never))) {
    process.stderr.write(`[make] ${line}\n`);
  }
  for (const line of describeCameraOverflows(detectCameraOverflows(manifestWithCues as never))) {
    process.stderr.write(`[make] ${line}\n`);
  }
  for (const scene of (manifestWithCues as {sceneTrack?: Array<{motor?: {diagnostics?: string[]}}>}).sceneTrack ?? []) {
    for (const diagnostic of scene.motor?.diagnostics ?? []) console.warn(`motor warning: ${diagnostic}`);
  }
  for (const line of describePropDiscontinuities(detectPropDiscontinuities(manifestWithCues as never))) {
    process.stderr.write(`[make] ${line}\n`);
  }
  return result;
}

/** Prepare/check and render a short QA preview when a manifest renderer exists. */
export async function previewYamlEpisode(
  ctx: StageContext,
  input: string,
  deps: YamlPipelineDependencies = {},
): Promise<YamlRenderResult> {
  const made = await makeYamlEpisode(ctx, input, {}, deps);
  const outPath = join(dirname(made.manifestPath), "dist", `${basename(dirname(made.manifestPath))}-preview.mp4`);
  const report = await renderYamlManifest(ctx, made, {duration: 5, force: true}, deps, outPath, true);
  if (!report) {
    process.stdout.write(`preview: prepared ${made.manifestPath}; manifest renderer is not installed\n`);
    return {...made, rendered: false};
  }
  process.stdout.write(`preview: wrote ${report.outPath}\n`);
  return {...made, rendered: true, outPath: report.outPath, report};
}

/** Prepare/check and render the canonical performance manifest. */
export async function renderYamlEpisode(
  ctx: StageContext,
  input: string,
  opts: YamlRenderOptions = {},
  deps: YamlPipelineDependencies = {},
): Promise<YamlRenderResult> {
  validateVoiceSpeed(opts.voiceSpeed, "render-yaml");
  const made = await makeYamlEpisode(ctx, input, {voiceSpeed: opts.voiceSpeed}, deps);
  const outPath = join(dirname(made.manifestPath), "dist", `${basename(dirname(made.manifestPath))}.mp4`);
  const report = await renderYamlManifest(ctx, made, opts, deps, outPath, false);
  if (!report) throw manifestRendererMissing();
  process.stdout.write(`render-yaml: wrote ${report.outPath} (${report.frames} frames)\n`);
  return {...made, rendered: true, outPath: report.outPath, report};
}

async function prepareYamlAudio(
  ctx: StageContext,
  episodePath: string,
  provider?: string,
  synthesizeUnmatched?: boolean,
  voiceSpeed?: number,
): Promise<YamlAudioPreparationArtifact> {
  const resolved = await resolveYamlEpisode(ctx, episodePath);
  const audioContext: StageContext = {
    ...ctx,
    rootDir: dirname(resolved.dir),
    config: {
      ...ctx.config,
      paths: {
        ...ctx.config.paths,
        episodes: ".",
      },
    },
  };
  await yamlAudioStage(audioContext, {
    episode: resolved.slug,
    ...(provider ? {provider} : {}),
    ...(synthesizeUnmatched ? {synthesizeUnmatched: true} : {}),
    ...(voiceSpeed !== undefined ? {voiceSpeed} : {}),
  });
  return readJson(join(resolved.dir, "audio", YAML_AUDIO_ARTIFACT_NAME), YamlAudioPreparationSchema);
}

async function renderYamlManifest(
  ctx: StageContext,
  made: YamlMakeResult,
  opts: YamlRenderOptions,
  deps: YamlPipelineDependencies,
  outPath: string,
  optional: boolean,
): Promise<RenderReport | undefined> {
  validateRenderOptions(opts);
  const request: YamlRenderRequest = {
    manifestPath: made.manifestPath,
    outPath,
    fps: opts.fps ?? ctx.config.video.fps,
    crf: opts.crf ?? ctx.config.video.crf,
    threads: opts.threads ?? ctx.config.render.concurrency,
    encode: ctx.config.render.encode,
    ...(opts.duration !== undefined ? {duration: opts.duration} : {}),
    ...(opts.scale !== undefined ? {scale: opts.scale} : {}),
    ...(opts.force !== undefined ? {force: opts.force} : {}),
  };
  if (deps.renderManifest) return deps.renderManifest(ctx, request);
  const renderer = ctx.registry.find("renderer", ctx.config.adapters.renderer) as (RendererAdapter & {
    renderManifest?: (request: YamlRenderRequest) => Promise<RenderReport>;
  }) | undefined;
  if (renderer?.renderManifest) return renderer.renderManifest(request);
  if (optional) return undefined;
  return undefined;
}

function validateRenderOptions(opts: YamlRenderOptions): void {
  if (opts.threads !== undefined && (!Number.isInteger(opts.threads) || opts.threads < 1)) {
    throw new Error("render-yaml: --threads must be a positive integer");
  }
  if (opts.duration !== undefined && (!Number.isFinite(opts.duration) || opts.duration <= 0)) {
    throw new Error("render-yaml: --duration must be greater than zero");
  }
  if (opts.scale !== undefined && (!Number.isFinite(opts.scale) || opts.scale <= 0)) {
    throw new Error("render-yaml: --scale must be greater than zero");
  }
  if (opts.fps !== undefined && (!Number.isInteger(opts.fps) || opts.fps < 1)) {
    throw new Error("render-yaml: --fps must be a positive integer");
  }
  if (opts.crf !== undefined && (!Number.isInteger(opts.crf) || opts.crf < 0 || opts.crf > 51)) {
    throw new Error("render-yaml: --crf must be an integer from 0 to 51");
  }
}

function validateVoiceSpeed(speed: number | undefined, command: "make" | "render-yaml"): void {
  if (speed !== undefined && (!Number.isFinite(speed) || speed <= 0)) {
    throw new Error(`${command}: --voice-speed must be greater than zero`);
  }
}

function performanceManifest(
  ctx: StageContext,
  resolved: ResolvedEpisode,
  compiled: CompiledEpisode,
  preparation: YamlAudioPreparationArtifact,
  at: string,
): Record<string, unknown> {
  return {
    version: 1,
    timebase: "seconds",
    video: ctx.config.video,
    duration: compiled.totalDuration,
    total: compiled.totalDuration,
    ...compiled,
    audio: preparation,
    generatedBy: {
      stage: "yaml-make",
      tool: "@anim/core/compileEpisode",
      at,
      inputHash: hashJson({episode: resolved.episode, audio: preparation}),
    },
  };
}

/**
 * Correlate take-level viseme cues with compiled speech events (same pairing
 * rule as speechStarts: per scene, takes in order zip speech events by start
 * time) and rewrite the top-level performance tracks with scene-absolute
 * `mouth` cue lists the renderer can consume.
 */
function attachSpeechMouth(compiled: CompiledEpisode, preparation: YamlAudioPreparationArtifact): void {
  const takesByScene = new Map<string, typeof preparation.takes>();
  for (const take of preparation.takes) {
    if (!take.mouth?.length) continue;
    const list = takesByScene.get(take.sceneId) ?? [];
    list.push(take);
    takesByScene.set(take.sceneId, list);
  }
  if (!takesByScene.size) return;
  for (const scene of compiled.sceneTrack) {
    const takes = takesByScene.get(scene.id);
    if (!takes?.length) continue;
    const speech = scene.performanceTracks
      .flatMap((track) => track.events)
      .filter((event): event is Extract<typeof event, {kind: "speech"}> => event.kind === "speech")
      .sort((a, b) => a.start - b.start);
    for (const [index, event] of speech.entries()) {
      const take = takes[index];
      if (!take?.mouth?.length) continue;
      const shift = event.start;
      const mouth = take.mouth.map((cue) => ({start: shift + cue.start, end: shift + cue.end, viseme: cue.viseme}));
      for (const track of compiled.performanceTracks) {
        if (track.subject !== event.subject) continue;
        for (const candidate of track.events) {
          if (candidate.kind !== "speech") continue;
          if (Math.abs(candidate.start - shift) > 0.05) continue;
          (candidate as {mouth?: typeof mouth}).mouth = mouth;
        }
      }
    }
  }
}

/** Rhubarb viseme analysis: attach per-take mouth cues for lip sync. */
async function attachMouthCues(ctx: StageContext, resolved: ResolvedEpisode, preparation: YamlAudioPreparationArtifact): Promise<void> {
  const lipsyncId = ctx.config.adapters.lipsync as string | undefined;
  if (!lipsyncId || lipsyncId === "none") return;
  const adapter = ctx.registry.find("lipsync", lipsyncId) as (LipsyncAdapter & { analyze?: unknown }) | undefined;
  if (!adapter?.analyze) return;
  const audioDir = join(resolved.dir, "audio");
  let analyzed = 0;
  for (const take of preparation.takes) {
    if (take.silence) continue;
    const wav = join(audioDir, `yaml-${take.id.replace(/[^a-zA-Z0-9._-]/g, "_")}.wav`);
    if (!existsSync(wav)) continue;
    try {
      const cues = await adapter.analyze({ audioPath: wav, dialogText: take.text });
      if (cues.length) {
        (take as { mouth?: unknown }).mouth = cues;
        analyzed++;
      }
    } catch (error) {
      process.stderr.write(`lipsync:${lipsyncId} — take ${take.id}: ${(error as Error).message?.split("\n")[0] ?? "unknown"}\n`);
    }
  }
  if (analyzed) process.stdout.write(`lipsync:${lipsyncId} — analyzed ${analyzed} take(s)\n`);
}

function speechStarts(preparation: YamlAudioPreparationArtifact, compiled: CompiledEpisode): Record<string, number> {
  const result: Record<string, number> = {};
  const takesByScene = new Map<string, typeof preparation.takes>();
  for (const take of preparation.takes) takesByScene.set(take.sceneId, [...(takesByScene.get(take.sceneId) ?? []), take]);
  for (const scene of compiled.sceneTrack) {
    const speech = scene.performanceTracks.flatMap((track) => track.events)
      .filter((event): event is Extract<typeof event, {kind: "speech"}> => event.kind === "speech")
      .sort((a, b) => a.start - b.start);
    for (const [index, event] of speech.entries()) {
      const take = takesByScene.get(scene.id)?.[index];
      if (take) result[take.id] = event.start;
    }
  }
  return result;
}

function resultOf(
  resolved: ResolvedEpisode,
  compiled: CompiledEpisode,
  spokenTakes: number,
  extra: Partial<YamlMakeResult> = {},
): YamlMakeResult {
  return {
    episodePath: resolved.path,
    episodeId: compiled.episode.id,
    scenes: resolved.episode.scenes.length,
    spokenTakes,
    audioPath: extra.audioPath ?? "",
    manifestPath: extra.manifestPath ?? "",
    totalDuration: extra.totalDuration ?? compiled.totalDuration,
  };
}

function libraryDir(ctx: StageContext): string {
  return resolvePath(ctx.rootDir, ctx.config.paths.library);
}

function spokenTakeCount(resolved: ResolvedEpisode): number {
  return segmentYamlAudio(yamlAudioSourceFromEpisode(resolved.episode)).length;
}

const dryRunSpeechTiming: SpeechTimingProvider = (request) => ({
  durationSec: 1,
  markers: Object.fromEntries(request.inlineTokens.map((token) => [token, 0])),
});

function speechTimingFromPreparation(preparation: YamlAudioPreparationArtifact): SpeechTimingProvider {
  const byId = new Map(preparation.takes.map((take) => [take.id, take]));
  return (request) => {
    const take = byId.get(request.lineId);
    if (!take) throw new Error(`make: audio preparation has no take for ${request.lineId}`);
    const markers: Record<string, number> = {};
    for (const event of take.inlineEvents) {
      if (event.atSec === null) {
        throw new Error(
          `make: audio take ${take.id} has no alignment for inline event at source offset ${event.sourceStart}; ` +
            "use an alignment-capable TTS provider",
        );
      }
      const relative = Math.max(0, Math.min(take.durationSec, event.atSec - take.timing.startSec));
      markers[event.name] = relative;
    }
    return {durationSec: take.durationSec, markers};
  };
}

function manifestRendererMissing(): Error {
  return new Error(
    "render-yaml: no renderer exposing renderManifest(manifestPath, ...) is registered",
  );
}
