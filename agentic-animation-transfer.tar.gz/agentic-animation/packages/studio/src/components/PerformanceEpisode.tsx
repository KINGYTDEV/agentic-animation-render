import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { evaluatePerformance, performanceMetadata } from "../performance";
import type {
    PerformanceFrameState,
    PerformanceManifest,
} from "../performance";
import { PerformanceActor } from "./performance/Actor";
import {nativeInteractionObjectIds} from "../performance/interactionLayers";
import { PerformanceProp } from "./performance/Prop";
import { PerformanceForegroundLayers, PerformanceStage, sceneForFrame } from "./performance/Stage";
import { PerformanceVfx } from "./performance/Vfx";
import {
    DebugFrameCounter,
    PhysicsDebugOverlay,
} from "./performance/PhysicsDebug";

export interface PerformanceEpisodeProps {
    /** Draw the physics debug overlay (figure/collider/hand/prop boxes). */
    debugPhysics?: boolean;
    manifest: PerformanceManifest;
    qaFrames?: number[];
}

export function resolvePerformanceFrame(
    renderFrame: number,
    qaFrames: number[],
    durationInFrames: number,
): number {
    const safeIndex = Number.isFinite(renderFrame)
        ? Math.max(0, Math.floor(renderFrame))
        : 0;
    const sample = qaFrames[Math.min(safeIndex, qaFrames.length - 1)] ?? 0;
    const safeFrame = Number.isFinite(sample)
        ? Math.max(0, Math.floor(sample))
        : 0;
    const safeDuration = Number.isFinite(durationInFrames)
        ? Math.max(1, Math.floor(durationInFrames))
        : 1;
    return Math.min(safeFrame, safeDuration - 1);
}

/** Manifest + frame are the only acting inputs. The SVG renderer has no clock,
 * filesystem access, image dependency, or mutable animation state. */
export const PerformanceEpisode: React.FC<PerformanceEpisodeProps> = ({
    manifest,
    qaFrames,
    debugPhysics,
}) => {
    const frame = useCurrentFrame();
    const evaluatedFrame = qaFrames?.length
        ? resolvePerformanceFrame(
              frame,
              qaFrames,
              performanceMetadata(manifest).durationInFrames,
          )
        : frame;
    return (
        <PerformanceFrame
            manifest={manifest}
            state={evaluatePerformance(manifest, evaluatedFrame)}
            debugPhysics={debugPhysics}
        />
    );
};

export const PerformanceFrame: React.FC<{
    manifest: PerformanceManifest;
    state: PerformanceFrameState;
    debugPhysics?: boolean;
}> = ({ manifest, state, debugPhysics }) => {
    const camera = state.camera;
    const scene = sceneForFrame(manifest, state.frame);
    const actors = state.actors
        .filter((actor) => actor.present)
        .sort((a, b) => a.z - b.z);
    const props = [...state.props].sort((a, b) => a.z - b.z);
    const nativeObjects = nativeInteractionObjectIds(manifest,actors);
    const foregroundProps = props.filter((prop)=>nativeObjects.has(prop.id));
    // A native object composites on the plane its holder stands on while it is
    // in that hand, and on its own staged plane once it is free (D1's depth
    // order, second defect of S-A1 review 3). A flat `zIndex: 50` painted every
    // palm-bound prop above the net's declared plane 45, so a served shuttle
    // drew over the net in every frame and could never cross it. `prop.z` is
    // the staged plane (35 for a `center` object, below the net's 45); 0 means
    // the manifest declared none, and the historical plane 50 is kept there.
    const heldPlane = new Map<string,number>();
    for (const actor of actors) {
        if (actor.artwork && actor.holds) heldPlane.set(actor.holds, actor.z);
        if (actor.artwork && actor.holdsL) heldPlane.set(actor.holdsL, actor.z);
    }
    const propPlane = (prop: {id: string; z: number}): number =>
        heldPlane.get(prop.id) ?? (prop.z > 0 ? prop.z : 50);
    const subtitle = state.subtitles.at(-1)?.text;
    const sceneVfx = state.vfx.filter((effect) =>
        Array.isArray(effect.targetPosition),
    );
    const backVfx = sceneVfx.filter((effect) =>
        ["back", "behind", "background"].includes(
            String(effect.layer ?? effect.depth ?? "").toLowerCase(),
        ),
    );
    const frontVfx = sceneVfx.filter((effect) => !backVfx.includes(effect));
    const stageVfx = state.vfx.filter((effect) => !sceneVfx.includes(effect));

    return (
        <AbsoluteFill
            data-performance-frame={state.frame}
            data-scene-id={scene.id}
            data-scene-theme={scene.theme}
            style={{
                background: manifest.background ?? "#20191a",
                overflow: "hidden",
            }}
        >
            <div
                data-camera={`${camera.x},${camera.y},${camera.z},${camera.rotation}`}
                style={{
                    position: "absolute",
                    inset: 0,
                    // Camera x/y are the viewport top-left in stage space (see
                    // containCamera), so the transform must scale about the top-left
                    // corner: screen = z*p - (x, y). A center origin would shift the
                    // whole stage and expose the background as black bands.
                    // Camera x/y are the viewport top-left in stage space, so the
                    // transform must compose as scale-then-translate-in-stage-units:
                    // screen = z*(p - x). A translate-first order turns x into a
                    // screen-space offset and leaks the background on zoomed-out pans.
                    transformOrigin: "0 0",
                    transform: `scale(${camera.z}) translate(${-camera.x}px, ${-camera.y}px) rotate(${camera.rotation}deg)`,
                    willChange: "transform",
                }}
            >
                <PerformanceStage scene={scene} />
                {backVfx.map((effect) => (
                    <PerformanceVfx key={effect.id} effect={effect} />
                ))}
                <div
                    data-layer="props"
                    style={{ position: "absolute", inset: 0, zIndex: 20 }}
                >
                    {props.filter((prop)=>!nativeObjects.has(prop.id)).map((prop) => (
                        <PerformanceProp key={prop.id} prop={prop} />
                    ))}
                </div>
                {/* One plane per actor (D1): each actor composites at its own
                    declared `z`, so a set layer whose declared depth sits
                    between two actor planes stands between them instead of
                    over both. One shared wrapper would carry its own stacking
                    context and flatten every actor onto a single plane. */}
                {actors.map((actor) => (
                    <div
                        key={actor.id}
                        data-layer="actors"
                        data-actor-plane={actor.z}
                        style={{ position: "absolute", inset: 0, zIndex: actor.z }}
                    >
                        <PerformanceActor
                            actor={actor}
                            props={props}
                            debugDiv={debugPhysics}
                        />
                    </div>
                ))}
                {/* One plane per native object, and one per gripping hand: an
                    object in a hand paints on the holder's plane, a free one on
                    its staged plane, and the hand that closes on it one plane
                    above it — never a flat plane above a declared set depth. */}
                {foregroundProps.length ? <>
                    {foregroundProps.map((prop)=>{const plane=propPlane(prop);return <div key={prop.id} data-layer="native-interaction-props" data-prop-plane={plane} style={{position:'absolute',inset:0,zIndex:plane}}>
                        <PerformanceProp prop={prop}/>
                    </div>;})}
                    {/* No `z-index` on this wrapper: it would open a stacking
                        context and push every hand plane under the actors. */}
                    <div data-layer="native-contact-hands" style={{position:'absolute',inset:0}}>
                        {actors.filter((actor)=>actor.artwork&&actor.gripDepth!=="behind"&&(actor.holds||actor.contact)).map((actor)=><div key={actor.id} data-layer="native-contact-hand" data-actor-plane={actor.z+1} style={{position:'absolute',inset:0,zIndex:actor.z+1}}><PerformanceActor actor={actor} props={props} handsOnly/></div>)}
                    </div>
                </> : null}
                {/* Declared foreground set layers occlude actors and props (M3). */}
                <PerformanceForegroundLayers scene={scene} />
                {frontVfx.map((effect) => (
                    <PerformanceVfx key={effect.id} effect={effect} />
                ))}
                <PhysicsDebugOverlay state={state} enabled={debugPhysics} />
            </div>
            <DebugFrameCounter frame={state.frame} enabled={debugPhysics} />
            {subtitle ? <PerformanceSubtitle text={subtitle} style={manifest.video?.captions} /> : null}
            {stageVfx.map((effect) => (
                <PerformanceVfx key={effect.id} effect={effect} />
            ))}
        </AbsoluteFill>
    );
};

const PerformanceSubtitle: React.FC<{
    text: string;
    style?: {
        color?: string;
        outlineColor?: string;
        outlineWidth?: number;
        fontScale?: number;
    };
}> = ({ text, style }) => {
    const baseSize = text.length > 60 ? 34 : text.length > 38 ? 40 : 48;
    const fontSize = Math.round(baseSize * (style?.fontScale ?? 1));
    const stroke = style?.outlineWidth ?? 0;
    const outline = style?.outlineColor ?? "#000000";
    const outlined = Boolean(style) && stroke > 0;
    const shadow = outlined
        ? `${stroke}px ${stroke}px 0 ${outline}, -${stroke}px -${stroke}px 0 ${outline}, ${stroke}px -${stroke}px 0 ${outline}, -${stroke}px ${stroke}px 0 ${outline}`
        : "4px 4px 0 #272331, -3px -3px 0 #272331, 3px -3px 0 #272331, -3px 3px 0 #272331";
    return (
        <div
            data-subtitle="voice"
            style={{
                position: "absolute",
                left: 96,
                right: 96,
                bottom: 24,
                zIndex: 300,
                color: style?.color ?? "#fff5dc",
                fontFamily: "Arial, 'Noto Sans CJK SC', sans-serif",
                fontSize,
                fontWeight: 900,
                lineHeight: 1.18,
                textAlign: "center",
                WebkitTextStroke: outlined ? `${stroke}px ${outline}` : undefined,
                paintOrder: outlined ? "stroke fill" : undefined,
                textShadow: shadow,
                whiteSpace: "pre-line",
            }}
        >
            {text}
        </div>
    );
};
