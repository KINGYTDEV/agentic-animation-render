import React from "react";
import type {SetLayerBlend} from "@anim/core";
import type { PerformanceManifest } from "../../performance";

const INK = "#272331";
const PAPER = "#fff0c4";
const FONT = "Arial, 'Noto Sans CJK SC', sans-serif";

export type PerformanceSceneTheme =
  | "opening-office" | "failure-incident" | "teaching-workshop" | "memory-archive" | "token-control"
  | "refactor-lab" | "quality-lab" | "security-night" | "workflow-command" | "ending-stage";

export interface PerformanceSceneContext {
  id: string;
  index: number;
  location: string;
  theme: PerformanceSceneTheme;
  sceneSvg?: string;
  /** Declared world layers with preloaded group text, back-to-front (M3); a
   * layer may declare compositing (M4 `blend`/`opacity`) or a paint plane
   * (`depth`, D1) at which it composites between the actor planes. */
  setLayers?: Array<{id: string; foreground: boolean; blend?: SetLayerBlend; opacity?: number; depth?: number; text: string}>;
  /** Intrinsic coordinateSpace extents of the set art (SVG viewBox). */
  setViewBox?: [number, number];
}

const THEME_BY_ID: Record<string, PerformanceSceneTheme> = {
  opening: "opening-office", failure_triad: "failure-incident", teach_ai: "teaching-workshop", memory: "memory-archive",
  token: "token-control", refactor_minimal: "refactor-lab", quality: "quality-lab", pitfalls: "security-night",
  workflow: "workflow-command", ending: "ending-stage",
};

/** Pure scene lookup: compiled scene seconds are converted with manifest fps. */
export function sceneForFrame(manifest: PerformanceManifest, frame: number): PerformanceSceneContext {
  const scenes = manifest.sceneTrack ?? [];
  const fps = manifest.video?.fps ?? 24;
  const safeFrame = Number.isFinite(frame) ? Math.max(0, Math.floor(frame)) : 0;
  const scene = scenes.find((candidate) => {
    const start = Math.round(candidate.start * fps);
    const end = Math.round(candidate.end * fps);
    return safeFrame >= start && safeFrame < Math.max(start + 1, end);
  }) ?? scenes.at(-1);
  if (!scene) return { id: "opening", index: 0, location: "office", theme: "opening-office" };
  const id = String(scene.id);
  const location = scene.location || scene.layout || "office";
  const setLayers = (scene.setLayers ?? []).flatMap((layer) => {
    const text = manifest.locationScenes?.[`${location}/${layer.id}`];
    return typeof text === "string" ? [{
      id: layer.id,
      foreground: layer.foreground === true,
      ...(layer.blend ? {blend: layer.blend} : {}),
      ...(layer.opacity === undefined ? {} : {opacity: layer.opacity}),
      ...(layer.depth === undefined ? {} : {depth: layer.depth}),
      text,
    }] : [];
  });
  return {
    id,
    index: Number.isFinite(scene.index) ? scene.index : scenes.indexOf(scene),
    location,
    theme: THEME_BY_ID[id] ?? themeForScene(scene.index),
    sceneSvg: manifest.locationScenes?.[location],
    ...(setLayers.length ? {setLayers} : {}),
    ...(scene.setViewBox ? {setViewBox: [scene.setViewBox[0], scene.setViewBox[1]] as [number, number]} : {}),
  };
}

function themeForScene(index: number): PerformanceSceneTheme {
  const fallback: PerformanceSceneTheme[] = ["opening-office", "failure-incident", "teaching-workshop", "memory-archive", "token-control", "refactor-lab", "quality-lab", "security-night", "workflow-command", "ending-stage"];
  return fallback[Math.max(0, Math.floor(index)) % fallback.length] ?? "opening-office";
}

interface StageProps { scene?: PerformanceSceneContext; }

/** viewBox of the declared coordinateSpace; 1920x1080 when undeclared. */
function setViewBoxOf(scene: PerformanceSceneContext): {width: number; height: number} {
  return scene.setViewBox ? {width: scene.setViewBox[0], height: scene.setViewBox[1]} : {width: 1920, height: 1080};
}

/** One declared set layer: intrinsic-space art scaled onto the 1920x1080 stage. */
const SetLayerSvg: React.FC<{scene: PerformanceSceneContext; layer: {id: string; foreground: boolean; blend?: SetLayerBlend; opacity?: number; depth?: number; text: string}; zIndex: number}> = ({scene, layer, zIndex}) => {
  const viewBox = setViewBoxOf(scene);
  return (
    <svg
      aria-label={`${scene.location} ${layer.id}`}
      data-stage="scene-layer"
      data-scene-id={scene.id}
      data-location={scene.location}
      data-set-layer={layer.id}
      data-set-foreground={layer.foreground ? "true" : undefined}
      data-set-blend={layer.blend}
      data-layer={layer.foreground ? "set-foreground" : "set-background"}
      viewBox={`0 0 ${viewBox.width} ${viewBox.height}`}
      width="1920"
      height="1080"
      dangerouslySetInnerHTML={{__html: layer.text}}
      style={{
        position: "absolute", inset: 0, zIndex, display: "block", overflow: "hidden",
        ...(layer.blend && layer.blend !== "normal" ? {mixBlendMode: layer.blend} : {}),
        ...(layer.opacity === undefined ? {} : {opacity: layer.opacity}),
      }}
    />
  );
};

/** Declared set layers above actors, replacing the single flat background. A
 * layer that declares a `depth` composites at that plane instead. */
export const PerformanceForegroundLayers: React.FC<StageProps> = ({scene}) => {
  const layers = (scene?.setLayers ?? []).filter((layer) => layer.foreground && layer.depth === undefined);
  return layers.length ? <>{layers.map((layer, index) => <SetLayerSvg key={layer.id} scene={scene!} layer={layer} zIndex={70 + index} />)}</> : null;
};

/** The plane a declared layer paints at: its declared `depth`, else today's
 * planes (background under the props at 20, foreground over the actors). */
const depthPlane = (layer: {foreground: boolean; depth?: number}, index: number): number => layer.depth ?? (layer.foreground ? 70 + index : index);

/** Flat, hard-edged scene dressing. It is rendered before props and actors,
 * except a layer that declares a `depth`: it paints at the plane it names,
 * which is how a set piece stands between two actors (D1, the net). */
export const PerformanceStage: React.FC<StageProps> = ({ scene = { id: "opening", index: 0, location: "office", theme: "opening-office" } }) => {
  const backgroundLayers = (scene.setLayers ?? []).filter((layer) => !layer.foreground);
  if (backgroundLayers.length) {
    return <>{backgroundLayers.map((layer, index) => <SetLayerSvg key={layer.id} scene={scene} layer={layer} zIndex={depthPlane(layer, index)} />)}</>;
  }
  return scene.sceneSvg ? (
  <svg
    aria-label={`${scene.location} ${scene.id} background`}
    data-stage="scene-background"
    data-scene-id={scene.id}
    data-scene-theme={scene.theme}
    data-location={scene.location}
    data-layer="background"
    viewBox="0 0 1920 1080"
    width="1920"
    height="1080"
    dangerouslySetInnerHTML={{__html: scene.sceneSvg.replace(/^\s*<svg\b[^>]*>/i, "").replace(/<\/svg>\s*$/i, "")}}
    style={{position: "absolute", inset: 0, zIndex: 0, display: "block", overflow: "hidden"}}
  />
) : (
  <svg aria-label={`${scene.location} ${scene.id} background`} data-stage="scene-background" data-scene-id={scene.id} data-scene-theme={scene.theme} data-location={scene.location} data-layer="background" viewBox="0 0 1920 1080" width="1920" height="1080" style={{ position: "absolute", inset: 0, display: "block", zIndex: 0 }}>
    {SCENE_ART[scene.theme]()}
  </svg>
  );
};

const SCENE_ART: Record<PerformanceSceneTheme, () => React.ReactNode> = {
  "opening-office": OpeningOffice, "failure-incident": FailureIncident, "teaching-workshop": TeachingWorkshop, "memory-archive": MemoryArchive,
  "token-control": TokenControl, "refactor-lab": RefactorLab, "quality-lab": QualityLab, "security-night": SecurityNight,
  "workflow-command": WorkflowCommand, "ending-stage": EndingStage,
};

const Text: React.FC<{ x: number; y: number; children: React.ReactNode; size?: number; fill?: string; anchor?: "start" | "middle" | "end" }> = ({ x, y, children, size = 30, fill = PAPER, anchor = "start" }) => <text x={x} y={y} textAnchor={anchor} fill={fill} fontSize={size} fontWeight="900" fontFamily={FONT}>{children}</text>;
const Panel: React.FC<{ x: number; y: number; w: number; h: number; fill: string; stroke?: string }> = ({ x, y, w, h, fill, stroke = INK }) => <rect x={x} y={y} width={w} height={h} fill={fill} stroke={stroke} strokeWidth="12" />;
const Floor: React.FC<{ fill: string; stripe?: string }> = ({ fill, stripe = "#e5ad52" }) => <><rect width="1920" height="720" fill={fill} /><rect y="720" width="1920" height="360" fill="#20191f" /><rect y="704" width="1920" height="26" fill={INK} /><rect y="730" width="1920" height="12" fill={stripe} /></>;
const Window: React.FC<{ x: number; y: number; w: number; h: number; sky: string }> = ({ x, y, w, h, sky }) => <g aria-label="window"><Panel x={x} y={y} w={w} h={h} fill={INK} /><rect x={x + 18} y={y + 18} width={w - 36} height={h - 36} fill={sky} /><path d={`M${x + w / 2} ${y + 18}V${y + h - 18}M${x + 18} ${y + h * .58}H${x + w - 18}`} stroke="#6b4a45" strokeWidth="14" /></g>;
const Desk: React.FC<{ x: number; w: number; fill?: string }> = ({ x, w, fill = "#70432f" }) => <g aria-label="workbench"><rect x={x} y="514" width={w} height="50" fill={fill} stroke={INK} strokeWidth="12" /><rect x={x + 42} y="564" width="44" height="150" fill={fill} stroke={INK} strokeWidth="10" /><rect x={x + w - 86} y="564" width="44" height="150" fill={fill} stroke={INK} strokeWidth="10" /></g>;
const Bolt: React.FC<{ x: number; y: number; fill?: string }> = ({ x, y, fill = "#f2c14e" }) => <circle cx={x} cy={y} r="9" fill={fill} stroke={INK} strokeWidth="5" />;

function OpeningOffice() { return <><Floor fill="#382c2b" /><Text x={78} y={70} size={38}>办公区 · Agent 作战台</Text><Text x={1840} y={70} anchor="end" size={25} fill="#d9e6d9">人定规则 · AI 执行</Text><Window x={50} y={110} w={540} h={320} sky="#b9e7e9" /><path d="M68 385Q180 265 286 374T570 350V412H68Z" fill="#79aaa8" stroke="#557b7a" strokeWidth="9" /><Panel x={748} y={105} w={736} h={300} fill="#b9774d" /><rect x="778" y="135" width="676" height="240" fill="#d69a63" stroke="#873f32" strokeWidth="12" /><Text x={1116} y={183} anchor="middle" size={37}>AI 项目作战墙</Text><Note x={812} y={220} w={180} h={110} fill="#fff5dc" rotate={-3}>先复述目标</Note><Note x={1035} y={225} w={160} h={105} fill="#c8e6d0" rotate={4}>正例 / 反例</Note><Note x={1238} y={220} w={178} h={112} fill="#f1c85f" rotate={-2}>最小权限</Note><Desk x={90} w={760} /><Desk x={1080} w={690} /><Panel x={62} y={548} w={240} h={140} fill="#d69a63" stroke="#873f32" /><Text x={182} y={596} anchor="middle" size={24} fill={INK}>咖啡续命站</Text><Text x={182} y={635} anchor="middle" size={18} fill="#873f32">今日第 4 杯</Text><Panel x={1198} y={570} w={310} h={108} fill="#f2d08c" stroke="#8d5039" /><Text x={1353} y={613} anchor="middle" size={21} fill="#8d5039">BUILD MONITOR</Text><Text x={1353} y={650} anchor="middle" size={22} fill="#d35b35">PASS · 24 TESTS</Text></> }

function FailureIncident() { return <><Floor fill="#442b32" stripe="#d95d4f" /><Text x={78} y={70} size={38}>故障响应室 · INCIDENT TRIAD</Text><Text x={1840} y={70} anchor="end" size={24} fill="#ffb39a">P1 · TRACE · RECOVER</Text><Panel x={70} y={126} w={530} h={310} fill="#251f32" /><rect x="100" y="160" width="470" height="210" fill="#d95d4f" stroke="#ffb39a" strokeWidth="10" /><Text x={335} y={235} anchor="middle" size={54} fill={INK}>500</Text><Text x={335} y={285} anchor="middle" size={23} fill={INK}>SERVICE UNAVAILABLE</Text><path d="M132 340h84l32-54 46 35 38-69 64 88h132" fill="none" stroke={INK} strokeWidth="10" /><Panel x={690} y={116} w={1110} h={328} fill="#633b3f" /><Text x={745} y={170} size={30}>现场证据墙 / 不要猜，先复现</Text><IncidentCard x={746} y={215} title="01 复述" body="输入 · 环境 · 预期" fill="#f2c14e" /><IncidentCard x={1090} y={215} title="02 缩小" body="最小失败样本" fill="#e7e1f4" /><IncidentCard x={1434} y={215} title="03 修复" body="验证 · 回滚" fill="#a6e7d9" /><Desk x={112} w={650} fill="#59372f" /><Desk x={1110} w={690} fill="#59372f" /><Panel x={1440} y={502} w={250} h={170} fill="#d95d4f" /><Text x={1565} y={555} anchor="middle" size={28} fill={INK}>ALERTS</Text><Text x={1565} y={612} anchor="middle" size={42} fill={INK}>3 → 0</Text></> }

function TeachingWorkshop() { return <><Floor fill="#263e4b" stripe="#58b6a6" /><Text x={78} y={70} size={38}>AI 教学工坊 · 把方法写成技能</Text><Text x={1840} y={70} anchor="end" size={24} fill="#b9e7e9">示范 · 练习 · 反馈</Text><Panel x={70} y={115} w={1120} h={330} fill="#dce9e4" /><Text x={110} y={168} size={30} fill={INK}>SKILL WORKSHOP</Text><path d="M125 230H1040M125 290H920M125 350H1080" stroke="#5e8390" strokeWidth="14" /><path d="M520 190v210M800 190v210" stroke="#d95d4f" strokeWidth="10" /><Text x={145} y={250} size={25} fill="#287f8f">输入</Text><Text x={575} y={250} size={25} fill="#d95d4f">规则</Text><Text x={850} y={250} size={25} fill="#287f8f">输出</Text><Panel x={1275} y={128} w={500} h={285} fill="#d69a63" /><Text x={1525} y={180} anchor="middle" size={28} fill={INK}>今日练习</Text><Note x={1330} y={215} w={175} h={112} fill="#f1c85f" rotate={-4}>正例</Note><Note x={1530} y={225} w={175} h={112} fill="#c8e6d0" rotate={3}>反例</Note><Desk x={95} w={710} fill="#3f6970" /><Desk x={1090} w={710} fill="#3f6970" /><Panel x={820} y={510} w={260} h={130} fill="#e7e1f4" /><Text x={950} y={566} anchor="middle" size={25} fill={INK}>问问题</Text><Text x={950} y={603} anchor="middle" size={21} fill="#6b4c91">WHY?</Text></> }

function MemoryArchive() { return <><Floor fill="#40374b" stripe="#c99ad9" /><Text x={78} y={70} size={38}>记忆档案室 · 可检索的上下文</Text><Text x={1840} y={70} anchor="end" size={24} fill="#e7e1f4">ARCHIVE · INDEX · RECALL</Text><Panel x={82} y={116} w={460} h={530} fill="#6a5066" /><Text x={312} y={172} anchor="middle" size={28}>档案柜 A—D</Text>{[0,1,2,3].map((i) => <g key={i}><rect x="124" y={210 + i * 92} width="376" height="62" fill={i % 2 ? "#c99ad9" : "#f1c85f"} stroke={INK} strokeWidth="8" /><Text x={153} y={250 + i * 92} size={20} fill={INK}>MEM-{String(i + 1).padStart(2, "0")} context</Text><Bolt x={470} y={240 + i * 92} fill="#fff0c4" /></g>)}<Panel x={635} y={120} w={1160} h={300} fill="#242334" /><Text x={695} y={176} size={28}>DOCUMENT TREE / 关联路径</Text><path d="M740 240h820M740 305h820M930 240v65M1190 240v65M1440 240v65M930 305l-90 72m350-72l-90 72m340-72l90 72" fill="none" stroke="#b9e7e9" strokeWidth="8" /><circle cx="740" cy="240" r="18" fill="#f2c14e" stroke={INK} strokeWidth="6" /><circle cx="930" cy="240" r="18" fill="#d95d4f" stroke={INK} strokeWidth="6" /><circle cx="1190" cy="240" r="18" fill="#a6e7d9" stroke={INK} strokeWidth="6" /><circle cx="1440" cy="240" r="18" fill="#f2c14e" stroke={INK} strokeWidth="6" /><Desk x={700} w={1050} fill="#5c4560" /><Panel x={850} y={492} w={550} h={170} fill="#fff5dc" /><Text x={1125} y={552} anchor="middle" size={28} fill={INK}>RECALL QUEUE</Text><Text x={1125} y={606} anchor="middle" size={23} fill="#6b4c91">3 related memories found</Text></> }

function TokenControl() { return <><Floor fill="#183c45" /><Text x={78} y={70} size={38}>Token 控制室 · 成本仪表盘</Text><Text x={1840} y={70} anchor="end" size={24} fill="#a6e7d9">BUDGET · ROUTE · CACHE</Text><Panel x={70} y={112} w={1780} h={360} fill="#102a35" /><Text x={115} y={168} size={29}>实时消耗 / 24h window</Text><path d="M140 395V230M140 395H820" stroke="#83d4c5" strokeWidth="8" /><path d="M180 358l90-28 80 18 100-76 92 46 100-120 110 42" fill="none" stroke="#f2c14e" strokeWidth="14" /><Text x={875} y={255} size={25} fill="#f2c14e">$ 18.42</Text><Text x={875} y={300} size={20} fill="#a6e7d9">-32% with cache</Text><Gauge x={1250} y={295} label="TOKENS" value="68%" color="#d95d4f" /><Gauge x={1510} y={295} label="BUDGET" value="41%" color="#a6e7d9" /><Desk x={95} w={690} fill="#245968" /><Desk x={1120} w={690} fill="#245968" /><Panel x={820} y={520} w={260} h={140} fill="#f1c85f" /><Text x={950} y={575} anchor="middle" size={25} fill={INK}>ROUTE</Text><Text x={950} y={615} anchor="middle" size={20} fill="#873f32">cheap → smart</Text><Panel x={1380} y={520} w={280} h={140} fill="#a6e7d9" /><Text x={1520} y={575} anchor="middle" size={25} fill={INK}>CACHE HIT</Text><Text x={1520} y={615} anchor="middle" size={20} fill="#155d68">72.8%</Text></> }

function RefactorLab() { return <><Floor fill="#3b3541" /><Text x={78} y={70} size={38}>重构实验室 · 最小可行改动</Text><Text x={1840} y={70} anchor="end" size={24} fill="#f1c85f">CUT · KEEP · PROVE</Text><Panel x={72} y={112} w={720} h={330} fill="#202936" /><Text x={112} y={168} size={28}>LEGACY MODULE</Text><ModuleBlock x={135} y={220} w={210} h={130} fill="#d95d4f" text="A" /><ModuleBlock x={405} y={220} w={210} h={130} fill="#d95d4f" text="B" /><path d="M345 285h60m270 0h72" stroke="#f2c14e" strokeWidth="12" /><Panel x={900} y={112} w={900} h={330} fill="#dce9e4" /><Text x={950} y={168} size={28} fill={INK}>SMALLER MODULES</Text><ModuleBlock x={960} y={225} w={220} h={105} fill="#a6e7d9" text="A1" /><ModuleBlock x={1260} y={225} w={220} h={105} fill="#a6e7d9" text="A2" /><ModuleBlock x={1560} y={225} w={180} h={105} fill="#f1c85f" text="TEST" /><Desk x={100} w={700} fill="#63483f" /><Desk x={1110} w={690} fill="#63483f" /><Panel x={830} y={520} w={230} h={135} fill="#fff5dc" /><Text x={945} y={576} anchor="middle" size={26} fill={INK}>DIFF</Text><Text x={945} y={615} anchor="middle" size={20} fill="#d95d4f">-47 lines</Text></> }

function QualityLab() { return <><Floor fill="#294452" /><Text x={78} y={70} size={38}>质量实验室 · 测试闭环</Text><Text x={1840} y={70} anchor="end" size={24} fill="#b9e7e9">RED · GREEN · REPEAT</Text><Panel x={70} y={112} w={1780} h={330} fill="#dce9e4" /><Text x={112} y={166} size={28} fill={INK}>TEST MATRIX</Text>{[0,1,2,3].map((row) => <g key={row}><Text x={126} y={232 + row * 54} size={19} fill="#5e6970">suite-{row + 1}</Text>{[0,1,2,3,4,5,6].map((col) => <rect key={col} x={295 + col * 180} y={202 + row * 54} width="112" height="30" fill={(row + col) % 5 === 0 ? "#d95d4f" : "#67b88d"} stroke={INK} strokeWidth="6" />)}</g>)}<Text x={1600} y={242} size={45} fill="#277e83">96%</Text><Text x={1600} y={280} size={18} fill={INK}>coverage</Text><Desk x={90} w={720} fill="#3d6170" /><Desk x={1100} w={700} fill="#3d6170" /><Tube x={880} y={535} fill="#d95d4f" /><Tube x={980} y={535} fill="#a6e7d9" /><Tube x={1080} y={535} fill="#f2c14e" /><Panel x={1310} y={500} w={360} h={155} fill="#f1c85f" /><Text x={1490} y={558} anchor="middle" size={26} fill={INK}>SHIP GATE</Text><Text x={1490} y={610} anchor="middle" size={22} fill="#287f8f">READY</Text></> }

function SecurityNight() { return <><Floor fill="#181d35" stripe="#d95d4f" /><Text x={78} y={70} size={38}>安全夜巡 · 陷阱与边界</Text><Text x={1840} y={70} anchor="end" size={24} fill="#ffb39a">NO SECRETS · NO SHORTCUTS</Text><Window x={75} y={120} w={530} h={330} sky="#25284b" /><circle cx="470" cy="185" r="42" fill="#f1c85f" stroke={INK} strokeWidth="8" /><path d="M118 405l70-75 62 62 90-104 80 117" fill="none" stroke="#4d567c" strokeWidth="12" /><Panel x={700} y={115} w={1100} h={340} fill="#25284b" /><Text x={752} y={172} size={30}>THREAT MAP / 信任边界</Text><path d="M800 260h780M800 335h780M1010 205v190M1310 205v190" stroke="#545d88" strokeWidth="9" /><rect x={845} y={230} width="120" height="68" fill="#a6e7d9" stroke={INK} strokeWidth="8" /><Text x={905} y={274} anchor="middle" size={18} fill={INK}>INPUT</Text><rect x={1135} y={230} width="170" height="68" fill="#f1c85f" stroke={INK} strokeWidth="8" /><Text x={1220} y={274} anchor="middle" size={18} fill={INK}>VALIDATE</Text><rect x={1450} y={230} width="170" height="68" fill="#d95d4f" stroke={INK} strokeWidth="8" /><Text x={1535} y={274} anchor="middle" size={18} fill={INK}>REJECT</Text><path d="M965 264h170m170 0h145" stroke="#fff0c4" strokeWidth="8" /><Desk x={110} w={680} fill="#293153" /><Desk x={1080} w={720} fill="#293153" /><Panel x={830} y={520} w={250} h={140} fill="#d95d4f" /><Text x={955} y={575} anchor="middle" size={23} fill={INK}>SECRET LEAK</Text><Text x={955} y={614} anchor="middle" size={22} fill={INK}>BLOCKED</Text></> }

function WorkflowCommand() { return <><Floor fill="#403748" stripe="#d6a2e7" /><Text x={78} y={70} size={38}>工作流指挥中心 · 并行与工单</Text><Text x={1840} y={70} anchor="end" size={24} fill="#e7e1f4">QUEUE · OWNER · DONE</Text><Panel x={70} y={112} w={1780} h={350} fill="#252334" /><Text x={112} y={168} size={29}>TODAY'S FLOW</Text>{["BACKLOG", "DOING", "VERIFY", "DONE"].map((label, i) => <g key={label}><rect x={110 + i * 425} y="205" width="375" height="210" fill={i === 3 ? "#315c58" : "#55415c"} stroke={INK} strokeWidth="10" /><Text x={140 + i * 425} y={248} size={22}>{label}</Text><rect x={140 + i * 425} y="275" width="300" height="38" fill={i === 1 ? "#f1c85f" : "#fff0c4"} stroke={INK} strokeWidth="6" /><rect x={140 + i * 425} y="335" width={i === 2 ? "220" : "270"} height="38" fill={i === 0 ? "#d95d4f" : "#a6e7d9"} stroke={INK} strokeWidth="6" /><Bolt x={420 + i * 425} y={294} /></g>)}<Desk x={90} w={720} fill="#604562" /><Desk x={1100} w={700} fill="#604562" /><Panel x={830} y={520} w={240} h={135} fill="#d6a2e7" /><Text x={950} y={575} anchor="middle" size={26} fill={INK}>OWNER</Text><Text x={950} y={614} anchor="middle" size={20} fill="#57243d">阿强 → 阿伟</Text></> }

function EndingStage() { return <><Floor fill="#382c2b" /><Text x={78} y={70} size={38}>终场舞台 · 人定规则，Agent 托管</Text><Text x={1840} y={70} anchor="end" size={24}>SHIP THE LEARNING</Text><path d="M70 110H1850L1690 520H230Z" fill="#d95d4f" stroke={INK} strokeWidth="14" /><path d="M160 140H1760L1620 470H300Z" fill="#f1c85f" stroke="#873f32" strokeWidth="10" /><Panel x={620} y={150} w={680} h={255} fill="#fff0c4" /><Text x={960} y={230} anchor="middle" size={42} fill={INK}>THE HUMAN LOOP</Text><Text x={960} y={285} anchor="middle" size={28} fill="#287f8f">规则 · 观察 · 复盘 · 迭代</Text><path d="M790 340h340" stroke="#d95d4f" strokeWidth="12" /><rect y="610" width="1920" height="110" fill="#241b28" stroke={INK} strokeWidth="14" /><path d="M160 720V1080M1760 720v360" stroke="#a45f3e" strokeWidth="46" /><Desk x={150} w={1620} fill="#70432f" /><Text x={960} y={982} anchor="middle" size={34} fill="#f2c14e">THANK YOU / 谢谢观看</Text></> }

const Note: React.FC<{ x: number; y: number; w: number; h: number; fill: string; rotate: number; children: React.ReactNode }> = ({ x, y, w, h, fill, rotate, children }) => <g transform={`rotate(${rotate} ${x + w / 2} ${y + h / 2})`}><rect x={x} y={y} width={w} height={h} fill={fill} stroke={INK} strokeWidth="6" /><Text x={x + w / 2} y={y + h / 2 + 8} anchor="middle" size={20} fill={INK}>{children}</Text></g>;
const IncidentCard: React.FC<{ x: number; y: number; title: string; body: string; fill: string }> = ({ x, y, title, body, fill }) => <g><rect x={x} y={y} width="290" height="150" fill={fill} stroke={INK} strokeWidth="8" /><Text x={x + 20} y={y + 48} size={22} fill={INK}>{title}</Text><Text x={x + 20} y={y + 95} size={18} fill={INK}>{body}</Text></g>;
const Gauge: React.FC<{ x: number; y: number; label: string; value: string; color: string }> = ({ x, y, label, value, color }) => <g><circle cx={x} cy={y} r="70" fill="#1d4e5a" stroke={color} strokeWidth="18" /><path d={`M${x - 44} ${y + 30}L${x - 14} ${y - 8}L${x + 45} ${y - 48}`} fill="none" stroke="#fff0c4" strokeWidth="10" /><Text x={x} y={y + 112} anchor="middle" size={21} fill="#a6e7d9">{label} · {value}</Text></g>;
const ModuleBlock: React.FC<{ x: number; y: number; w: number; h: number; fill: string; text: string }> = ({ x, y, w, h, fill, text }) => <g><rect x={x} y={y} width={w} height={h} fill={fill} stroke={INK} strokeWidth="10" /><Text x={x + w / 2} y={y + h / 2 + 15} anchor="middle" size={38} fill={INK}>{text}</Text></g>;
const Tube: React.FC<{ x: number; y: number; fill: string }> = ({ x, y, fill }) => <g><rect x={x} y={y} width="60" height="130" fill={fill} stroke={INK} strokeWidth="8" /><path d={`M${x} ${y + 50}h60M${x + 10} ${y + 80}h40`} stroke="#fff5dc" strokeWidth="7" /></g>;
